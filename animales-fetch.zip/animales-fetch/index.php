<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
    <h1>Hola mundo</h1>
    <p>Esto es un ejemplo de fetch con php Y JS</p>


    <div id="listaAnimales" style="display: grid;grid-template-columns: repeat(3, 1fr); background-color:red; gap:10px; border: solid;" >

    </div>

 <button id="mostrarAnimales"> Presiona </button>


<script src="app.js"></script>
</body>
</html>